#creating float variables
length=12.35
width=14.67
#calculating area
area=length*width
#result as integer
print(f"Area: {int(area)}")


