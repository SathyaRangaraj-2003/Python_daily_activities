#activity 01
'''reassign A with C,B with A,C with B 
without temporary variables and
 multiple line of code '''


#declaring variables
a=10
b=20
c=30
a,b,c=c,a,b #reassigning
print(a,b,c)