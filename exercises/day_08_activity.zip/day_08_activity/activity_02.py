#activity 02  
#o/p => ['makes', 'you','think'] ,single line of python code can retrive the output

sentence ="Python makes you think differently" #declaring
first,*middle,last=sentence.split(" ") 
print(middle)
